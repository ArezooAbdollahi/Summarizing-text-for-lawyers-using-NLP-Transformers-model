import rouge
from nltk.tokenize import sent_tokenize

def cartesian_list(sentences):
    for idx, sent in enumerate(sentences):
        yield sent, (sentences[:idx] + sentences[idx+1:])

def get_best_rouge_idx(sentences):
    scores = []

    for hypothesis, references in cartesian_list(sentences):
        evaluator = rouge.Rouge(metrics=["rouge-l"],
                                limit_length=True,
                                length_limit=100,
                                length_limit_type="words",
                                apply_best=True,
                                alpha=0.5, # Default F1_score
                                weight_factor=1.2,
                                stemming=True)

        cur_score = evaluator.get_scores(hypothesis, references)
        scores.append(cur_score["rouge-l"]["f"])
    
    return scores.index(min(scores))

def extract_important_sentence(paragraph):
    print(paragraph)
    sentences = sent_tokenize(paragraph[0])
    idx = get_best_rouge_idx(sentences)

    return sentences[idx]

# USAGE:
# paragraph = """
# The storm has caused at least two deaths in the Dominican Republic and torn down trees, 
# flooded streets and knocked out power for thousands of homes and businesses in Puerto Rico, 
# according to media reports. Hurricane Isaias strengthened slightly as it lashed the Bahamas on Saturday, 
# bearing down on Florida and was expected to approach the southeast of the state 
# later in the day before travelling up the eastern U.S. seaboard. Isaias was carrying 
# top sustained winds of 140 km/h and was located about 125 kilometres south-southeast 
# of the Bahamas capital Nassau at 5 a.m. ET, heading northwest, the U.S. National 
# Hurricane Center said. Its centre was approaching Andros Island in the Bahamas and 
# was due to pass over or near islands in the central and northwest Bahamas on Saturday, 
# bringing a danger of damaging storm surges of up to 1.52 metres over normal tide 
# levels, the NHC said. The storm, a Category 1 on the five-step Saffir-Simpson scale,
# prompted authorities in parts of Florida to close COVID-19 testing sites and people
# to stock up on essentials.
# """

# important_sent = extract_important_sentence(paragraph)
# print("Important sentence:")
# print(important_sent)