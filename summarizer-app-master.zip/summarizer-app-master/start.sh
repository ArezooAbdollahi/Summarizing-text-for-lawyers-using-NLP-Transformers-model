#!/bin/bash

source activate mlflow-env-iris

python /root/app.py