BART_MODEL_NAME = "facebook/bart-large-xsum"
BART_TOKENIZER = "facebook/bart-large-xsum"
PARAGRAPH_SZ = 125
WINDOW_SZ = 10