from rank_bm25 import BM25Okapi
from constants import PARAGRAPH_SZ, WINDOW_SZ

class ParagraphRanker():
    def __init__(self, document):
        self.corpus = self.split_paragraphs(document)
        self.bm25 = self.set_scoring_function()

    def split_paragraphs(self, document):
        content = document.split()
        paragraphs = [
            " ".join(content[i-1:i+PARAGRAPH_SZ]) for i in range(
                WINDOW_SZ,
                len(content),
                PARAGRAPH_SZ
            )
        ]

        return paragraphs

    def set_scoring_function(self):
        tokenized_corpus = [doc.split(" ") for doc in self.corpus]
        return BM25Okapi(tokenized_corpus)

    def score_paragraphs(self, query, n=1):
        tokenized_query = query.split(" ")
        return self.bm25.get_top_n(tokenized_query, self.corpus, n=n)
