import json

from transformers import BartTokenizer, BartForConditionalGeneration, BartConfig
from torch import nn

from reranker import ParagraphRanker
from constants import BART_MODEL_NAME, BART_TOKENIZER
from rouge_baseline import extract_important_sentence

class Summarizer(nn.Module):
    def __init__(self, content, use_bart=False):
        super(Summarizer, self).__init__()
        self.content = content
        self.use_bart = use_bart

        # see ``examples/summarization/bart/run_eval.py`` for a longer example
        self.model = BartForConditionalGeneration.from_pretrained(BART_MODEL_NAME)
        self.tokenizer = BartTokenizer.from_pretrained(BART_TOKENIZER)

    def get_top_paragraph(self, query, k=1):
        para_ranker = ParagraphRanker(self.content)
        top_paragraph = para_ranker.score_paragraphs(query=query, n=k)

        return top_paragraph

    def get_summaries(self, query):
        top_paragraph = self.get_top_paragraph(query=query)

        if self.use_bart:
            inputs = self.tokenizer(
                [str(top_paragraph)],
                max_length=1024,
                return_tensors="pt"
            )

            # Generate Summary
            summary_ids = self.model.generate(
                inputs["input_ids"],
                num_beams=15,
                max_length=155,
                early_stopping=True
            )

            return [
                self.tokenizer.decode(
                    g,
                    skip_special_tokens=True,
                    clean_up_tokenization_spaces=False
                ) for g in summary_ids
            ]

        return extract_important_sentence(paragraph=top_paragraph)


if __name__ == "__main__":
    with open("sample_file.json") as patent_file:
        patent_data = json.load(patent_file)

    summarizer = Summarizer(content=patent_data["description"])
    summaries  = summarizer.get_summaries(query="ink pattern")


    print("SUMMARY")
    print("*"*20)
    print(summaries)

    summarizer = Summarizer(content=patent_data["description"], use_bart=True)
    summaries  = summarizer.get_summaries(query="pad printing")
    print("SUMMARY")
    print("*"*20)
    print(summaries)
