# summarizer-app



## Poetry

Once poetry is installed, in this repository execute the following command:

```bash
$ poetry install
```

To use the virtual environment, do the following:

```bash
$ poetry shell
```

To add a package :

```bash
$ poetry add <package>
```

To remove a package

```bash
$ poetry remove package
```

If you are pullling from github, always do `poetry install` in case someone else has added a dependency


## Pyenv

Once pyenv is installed, you can install a peynv version of python. For `python 3.8.2` use the following command:

```bash
$ pyenv install 3.8.2
```

To specify the version of python you would like to use in a given repo (or any folder for that matter) simply type the following command:

```bash
$ pyenv local <python version>
```

