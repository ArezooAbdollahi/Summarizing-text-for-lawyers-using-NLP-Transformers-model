import tensorflow_datasets as tfds

class Dataset():
    def __init__(self):
        self.dataset = tfds.load(
            'MultiNews',
            split='train',
            # shuffle_files=True
        )

    def fetch_doc(self, n=1):
        for example in self.dataset.take(n):
            doc = example["document"].numpy()
            summary = example["summary"].numpy()

        return doc, summary
